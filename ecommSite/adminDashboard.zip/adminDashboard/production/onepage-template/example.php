
<?php
$str = "admintwo@123";
echo md5($str);
?>
