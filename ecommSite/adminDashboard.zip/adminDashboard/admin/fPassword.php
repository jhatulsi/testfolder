<form class="form-signin" method="POST" action="forgetpassword.php">
        <h2 class="form-signin-heading">Forgot Password</h2>
        <div class="input-group">
	  <span class="input-group-addon" id="basic-addon1">@</span>
	  <input type="text" name="email" class="form-control" placeholder="Username" id="email" required>
	</div>
	<br />
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="submit" name="submit">Forgot Password</button>
        <a class="btn btn-lg btn-primary btn-block" href="login.php">Login</a>
      </form>